def sum(x:int , y:int)->int:
    z:int = x + y
    return z
def main():
    print(sum(1,2))
if __name__ == "__main__":
    main()
    
