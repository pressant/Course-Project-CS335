def bubbleSort(array:int) -> None:
    x:int = 5
    print(array)



def main():
  data: int = 2
  bubbleSort(data)
