def main()->None:
    x:int = 5
    print(x)

    
