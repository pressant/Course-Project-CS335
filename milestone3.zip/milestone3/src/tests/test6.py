i:int = 0
x:int = 1
for i in range(10):
    x = x +i
if(x>10):
    x = x + 1
else:
    x = x - 1    
print(x)
